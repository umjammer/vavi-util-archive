/*
 * Copyright (c) 2002 by Naohide Sano, All rights reserved.
 *
 * Programmed by Naohide Sano
 */

import java.io.*;
import java.util.*;
import javax.swing.event.*;
import javax.swing.table.*;
import vavi.util.archive.*;

/**
 * EntryTableModel
 *
 * @author	<a href=mailto:vavivavi@yahoo.co.jp>Naohide Sano(nsano)</a>
 * @version	0.00	021103	nsano	initial version <br>
 */
public class EntryTableModel extends AbstractTableModel {

    /** �J�����̖��O */
    private static final String columnName[] = {
	"Name",
	"Type",
        "Modified",
        "Size",
        "Ratio",
        "Packed",
        "Path"
    };

    /** */
    private static final int[] widths = { 150, 80, 100, 60, 40, 60, 320 };

    private Entry[] entries;

    /** �e�[�u�����f�����\�z���܂��D */
    public EntryTableModel(Archive archive) {
        entries = archive.entries();
    }

    //-------------------------------------------------------------------------

    /** �J���������擾���܂��D */
    public int getColumnCount() {
	return columnName.length;
    }

    /** �J���������擾���܂��D */
    public String getColumnName(int columnIndex) {
	return columnName[columnIndex];
    }

    /** �s�����擾���܂��D */
    public int getRowCount() {
	return entries.length;
    }

    /** �w�肵���J�����C�s�ɂ���l���擾���܂��D */
    public Object getValueAt(int rowIndex, int columnIndex) {
        switch (columnIndex) {
        case 0:
            return entries[rowIndex].getName();
        case 1:
            return null;
        case 2:
            return new Long(entries[rowIndex].getTime());
        case 3:
            return new Long(entries[rowIndex].getSize());
        case 4:
            long originalSize = entries[rowIndex].getSize();
            long packedSize = entries[rowIndex].getCompressedSize();
            return new Integer((int)(packedSize / originalSize * 100));
        case 5:
            return new Long(entries[rowIndex].getCompressedSize());
        case 6:
            return entries[rowIndex].getName();
        default:
            throw new IllegalArgumentException();
        }
    }
}

/* */
