/*
 * Copyright (c) 2002 by Naohide Sano, All rights reserved.
 *
 * Programmed by Naohide Sano
 */

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.text.*;
import java.util.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import vavi.swing.*;
import vavi.util.*;
import vavi.util.archive.*;

/**
 * Java version of winzip.
 *
 * @author	<a href=mailto:vavivavi@yahoo.co.jp>nsano</a>
 * @version	0.00	021103	nsano	initial version <br>
 */
public class JWinZip {

    /** */
    private static final ResourceBundle rb =
	ResourceBundle.getBundle("JWinZipResource", Locale.getDefault());

    //-------------------------------------------------------------------------

    /**
     *
     */
    private JWinZip(String[] args) throws IOException {
        JFrame frame = new JFrame();

        JTable table = new JTable();
        table.setModel(new EntryTableModel(new vavi.util.archive.spi.LhaArchive(new File(args[0]))));

        frame.getContentPane().add(table);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.show();
    }

    //-------------------------------------------------------------------------

    /**
     * The program entry point.
     */
    public static void main(String[] args) throws IOException {
        new JWinZip(args);
    }
}

/* */
