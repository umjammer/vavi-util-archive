/*
 * Copyright (c) 2002 by Naohide Sano, All rights reserved.
 *
 * Programmed by Naohide Sano
 */

package vavi.util.archive.vavi;

import java.io.File;
import java.io.IOException;


/**
 * RAR �A�[�J�C�u����������T�[�r�X�v���o�C�_�ł��D
 * (COM �o�[�W����)
 *
 * @target	1.1
 *
 * @author	<a href="mailto:vavivavi@yahoo.co.jp">Naohide Sano</a> (nsano)
 * @version	0.00	030211	nsano	initial version <br>
 */
public class ComRarArchive extends ComArchive {
    
    /** */
    public ComRarArchive(File file) throws IOException {
        super(file, TYPE_RAR);
    }
    
    /** */
    public static void main(String[] args) throws Exception {
        new ComRarArchive(new File(args[0]));
    }
}

/* */
