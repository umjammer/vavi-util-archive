/*
 * Copyright (c) 2002 by Naohide Sano, All rights reserved.
 *
 * Programmed by Naohide Sano
 */

package vavi.util.archive.vavi;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import com.jacob.activeX.ActiveXComponent;
import com.jacob.com.ComThread;
import com.jacob.com.Dispatch;
import com.jacob.com.Variant;

import vavi.util.Debug;
import vavi.util.archive.Archive;
import vavi.util.archive.Entry;
import vavi.util.archive.spi.CommonEntry;
import vavi.util.win32.DateUtil;


/**
 * KBA front end�D
 *
 * @target	1.1
 * 
 * @author	<a href="mailto:vavivavi@yahoo.co.jp">Naohide Sano</a> (nsano)
 * @version	0.00	030211	nsano	initial version <br>
 */
public class ComArchive implements Archive {

    /** */
    public static final String TYPE_LHA = "UNLHA";
    /** */
    public static final String TYPE_FTP = "FTP";
    /** */
    public static final String TYPE_TAR = "TAR";
    /** */
    public static final String TYPE_CAB = "CAB";
    /** */
    public static final String TYPE_ZIP = "ZIP";
    /** */
    public static final String TYPE_ARJ = "UNARJ";
    /** */
    public static final String TYPE_RAR = "UNRAR";
    /** */
    public static final String TYPE_UNZIP = "UNZIP";
    /** */
    public static final String TYPE_ISH = "ISH";

    /** */
    private String type;

    /** */
    private List<Entry> entries = new ArrayList<Entry>();

    /** */
    private Object manager;
    /** */
    private Object module;

    /** */
    private File file;

    /** */
    public ComArchive(File file, String type) {

        this.file = file;

Debug.println("type: " + type);
        ComThread.InitSTA();

        // manager
        ActiveXComponent activex = new ActiveXComponent("KBA.Manager");
        manager = activex.getObject();

Debug.println("version: " + Dispatch.get(manager, "Ver"));
Debug.println("unlha: " + Dispatch.get(manager, "UnlhaOk").getBoolean());
Debug.println("ftp: "   + Dispatch.get(manager, "FtpOk").getBoolean());
Debug.println("cab: "   + Dispatch.get(manager, "CabOk").getBoolean());
Debug.println("zip: "   + Dispatch.get(manager, "ZipOk").getBoolean());
Debug.println("unarj: " + Dispatch.get(manager, "UnarjOk").getBoolean());
Debug.println("unrar: " + Dispatch.get(manager, "UnrarOk").getBoolean());
Debug.println("unzip: " + Dispatch.get(manager, "UnzipOk").getBoolean());
Debug.println("ish: "   + Dispatch.get(manager, "IshOk").getBoolean());

	Object result = Dispatch.invoke(manager, "ArcClass", Dispatch.Method, new Object[] { type }, new int[1]);
Debug.println("arcClass: " + ComUtil.toObject((Variant) result));

	// each module
	activex = new ActiveXComponent("KBA." + type);
        module = activex.getObject();

if ("ZIP".equals(type)) {
Debug.println("version: " + Dispatch.get(module, "VerUnZip"));
} else {
Debug.println("version: " + Dispatch.get(module, "Ver"));
}
Debug.println("interval: " + Dispatch.get(module, "CursorInterval"));
Debug.println("background: " + Dispatch.get(module, "BackgroundMode"));
Debug.println("cursorMode: " + Dispatch.get(module, "CursorMode"));
Debug.println("running: " + Dispatch.get(module, "Running"));
	result = Dispatch.invoke(module, "OpenArc", Dispatch.Method, new Object[] { file.toString() }, new int[1]);
Debug.println("openArc: " + ComUtil.toObject((Variant) result));

	while (true) {
            result = Dispatch.invoke(module, "Find", Dispatch.Method, new Object[] { "*" }, new int[1]);
            if (!((Variant) result).toBoolean()) {
                break;
            }

            CommonEntry entry = new CommonEntry();

            Object value = Dispatch.get(module, "FileName");
Debug.println("name: " + value.getClass() + ": " + ComUtil.toObject((Variant) value));
            entry.setName(((Variant) value).toString());

            value = Dispatch.get(module, "FileTime");
Debug.println("time: " + value.getClass() + ": " + ComUtil.toObject((Variant) value));
            entry.setTime(DateUtil.dateToLong(((Variant) value).toDate()));

            value = Dispatch.get(module, "FileAttr");
Debug.println("attr: " + value.getClass() + ": " + ComUtil.toObject((Variant) value));

	    value = Dispatch.get(module, "FileMode");
Debug.println("mode: " + value.getClass() + ": " + ComUtil.toObject((Variant) value));

            value = Dispatch.get(module, "OriginalSize");
Debug.println("size: " + value.getClass() + ": " + ComUtil.toObject((Variant) value));
            entry.setSize(((Variant) value).toInt());

            value = Dispatch.get(module, "CompressedSize");
Debug.println("compressed: " + value.getClass() + ": " + ComUtil.toObject((Variant) value));
            entry.setCompressedSize(((Variant) value).toInt());

	    value = Dispatch.get(module, "Ratio");
Debug.println("ratio: " + value.getClass() + ": " + ComUtil.toObject((Variant) value));

	    entries.add(entry);

            result = Dispatch.invoke(module, "FindNext", Dispatch.Method, new Object[] {}, new int[1]);
Debug.println("findNext: " + ComUtil.toObject((Variant)result));
        }
/*
        "ArcDateTime";
        "ArcOriginalSize";
        "ArcCompressedSize";
        "ArcRatio";
*/
        ComThread.Release();
    }

    /**
     * �t�@�C������܂��B
     */
    public void close() throws IOException {
        ComThread.InitSTA();
        Object result = Dispatch.invoke(module, "CloseArc", Dispatch.Method, new Object[] {}, new int[1]);
Debug.println(ComUtil.toObject((Variant)result));
        ComThread.Release();
    }

    /**
     * �t�@�C���G���g���̗񋓂�Ԃ��܂��B
     */
    public Entry[] entries() {
        Entry[] entries = new Entry[this.entries.size()];
        this.entries.toArray(entries);
        return entries;
    }

    /**
     * �w�肳�ꂽ���O�� RAR �t�@�C���G���g����Ԃ��܂��B
     * ������Ȃ��ꍇ�� null ��Ԃ��܂��B
     */
    public Entry getEntry(String name) {
        for (Entry entry : entries) {
            if (entry.getName().equals(name)) {
                return entry;
            }
        }
        return null;
    }

    /**
     * �w�肳�ꂽ �t�@�C���G���g���̓��e��ǂݍ��ނ��߂̓��̓X�g���[����
     * �Ԃ��܂��B
     */
    public InputStream getInputStream(Entry entry) throws IOException {
        ComThread.InitSTA();
        Object result = Dispatch.invoke(module, "ArcCmd", Dispatch.Method, new Object[] { "command" }, new int[1]);
Debug.println(ComUtil.toObject((Variant) result));
        ComThread.Release();
        return null;
    }

    /**
     * �t�@�C���̃p�X����Ԃ��܂��B
     */
    public String getName() {
        return file.getPath();
    }

    /**
     * �t�@�C�����̃G���g���̐���Ԃ��܂��B
     */
    public int size() {
        return entries.size();
    }
}

/* */
